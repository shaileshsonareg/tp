import Add from "./Add"
import Sqr from "./Sqr"
import Users from "./Users"

function App() {

  return (
    <>
      <h1>Hello from react app component</h1>  
      {/* <Component prop1={value1} prop2={value2} /> */}
      {/* <Sqr num={5} />  
      <Sqr num={6} />  
      <Sqr num={7} />   */}
      {/* <Add /> */}
      <Users />
      </>
  )
}

export default App
