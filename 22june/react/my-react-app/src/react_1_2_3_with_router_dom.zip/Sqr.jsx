import React from 'react'

export default function Sqr() {
    var x = 7
  return (
    <div>Square of {x} is {x * x}</div>
  )
}
