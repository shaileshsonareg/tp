import React from 'react'

export const Sqr = (props) => {

    var x = props.num

  return (
    <div>Square of {x} is {x * x}</div>
  )
}
