import Fruits from "./Fruits"
import Header from "./Header"
import { Sqr } from "./Sqr"
import Users from "./Users"

function App() {

  return (
    // React Fragment
    <>  
      <Users />
      {/* <Fruits /> */}
      {/* <Header />
      <Sqr num={5} />
      <Sqr num={6} />
      <Sqr num={7} />
      Hello World */}
    </>
  )
}

export default App
